package net.minecraft.client.data.models.model;

import com.mojang.math.Transformation;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import net.minecraft.client.color.item.Constant;
import net.minecraft.client.color.item.ItemTintSource;
import net.minecraft.client.renderer.item.RangeSelectItemModel.Entry;
import net.minecraft.client.renderer.item.SelectItemModel.SwitchCase;
import net.minecraft.client.renderer.item.SelectItemModel.UnbakedSwitch;
import net.minecraft.client.renderer.item.properties.conditional.ConditionalItemModelProperty;
import net.minecraft.client.renderer.item.properties.conditional.HasComponent;
import net.minecraft.client.renderer.item.properties.conditional.IsUsingItem;
import net.minecraft.client.renderer.item.properties.numeric.RangeSelectItemModelProperty;
import net.minecraft.client.renderer.item.properties.select.ContextDimension;
import net.minecraft.client.renderer.item.properties.select.ItemBlockState;
import net.minecraft.client.renderer.item.properties.select.LocalTime;
import net.minecraft.client.renderer.item.properties.select.SelectItemModelProperty;
import net.minecraft.client.renderer.special.SpecialModelRenderer.Unbaked;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.resources.Identifier;
import net.minecraft.util.SpecialDates;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.properties.Property;

public class ItemModelUtils {
	public static net.minecraft.client.renderer.item.ItemModel.Unbaked plainModel(final Identifier id) {
		return new net.minecraft.client.renderer.item.CuboidItemModelWrapper.Unbaked(id, Optional.empty(), List.of());
	}

	public static net.minecraft.client.renderer.item.ItemModel.Unbaked plainModel(final Identifier id, final Transformation transformation) {
		return new net.minecraft.client.renderer.item.CuboidItemModelWrapper.Unbaked(id, Optional.of(transformation), List.of());
	}

	public static net.minecraft.client.renderer.item.ItemModel.Unbaked tintedModel(final Identifier id, final ItemTintSource... tints) {
		return new net.minecraft.client.renderer.item.CuboidItemModelWrapper.Unbaked(id, Optional.empty(), List.of(tints));
	}

	public static ItemTintSource constantTint(final int color) {
		return new Constant(color);
	}

	public static net.minecraft.client.renderer.item.ItemModel.Unbaked composite(final net.minecraft.client.renderer.item.ItemModel.Unbaked... models) {
		return new net.minecraft.client.renderer.item.CompositeModel.Unbaked(List.of(models), Optional.empty());
	}

	public static net.minecraft.client.renderer.item.ItemModel.Unbaked specialModel(final Identifier base, final Unbaked<?> model) {
		return specialModel(base, Optional.empty(), model);
	}

	public static net.minecraft.client.renderer.item.ItemModel.Unbaked specialModel(
		final Identifier base, final Transformation transformation, final Unbaked<?> model
	) {
		return specialModel(base, Optional.of(transformation), model);
	}

	public static net.minecraft.client.renderer.item.ItemModel.Unbaked specialModel(
		final Identifier base, final Optional<Transformation> transformation, final Unbaked<?> model
	) {
		return new net.minecraft.client.renderer.item.SpecialModelWrapper.Unbaked(base, transformation, model);
	}

	public static Entry override(final net.minecraft.client.renderer.item.ItemModel.Unbaked model, final float value) {
		return new Entry(value, model);
	}

	public static net.minecraft.client.renderer.item.ItemModel.Unbaked rangeSelect(
		final RangeSelectItemModelProperty property, final net.minecraft.client.renderer.item.ItemModel.Unbaked fallback, final Entry... entries
	) {
		return new net.minecraft.client.renderer.item.RangeSelectItemModel.Unbaked(Optional.empty(), property, 1.0F, List.of(entries), Optional.of(fallback));
	}

	public static net.minecraft.client.renderer.item.ItemModel.Unbaked rangeSelect(
		final RangeSelectItemModelProperty property, final float scale, final net.minecraft.client.renderer.item.ItemModel.Unbaked fallback, final Entry... entries
	) {
		return new net.minecraft.client.renderer.item.RangeSelectItemModel.Unbaked(Optional.empty(), property, scale, List.of(entries), Optional.of(fallback));
	}

	public static net.minecraft.client.renderer.item.ItemModel.Unbaked rangeSelect(
		final RangeSelectItemModelProperty property, final net.minecraft.client.renderer.item.ItemModel.Unbaked fallback, final List<Entry> entries
	) {
		return new net.minecraft.client.renderer.item.RangeSelectItemModel.Unbaked(Optional.empty(), property, 1.0F, entries, Optional.of(fallback));
	}

	public static net.minecraft.client.renderer.item.ItemModel.Unbaked rangeSelect(final RangeSelectItemModelProperty property, final List<Entry> entries) {
		return new net.minecraft.client.renderer.item.RangeSelectItemModel.Unbaked(Optional.empty(), property, 1.0F, entries, Optional.empty());
	}

	public static net.minecraft.client.renderer.item.ItemModel.Unbaked rangeSelect(
		final RangeSelectItemModelProperty property, final float scale, final List<Entry> entries
	) {
		return new net.minecraft.client.renderer.item.RangeSelectItemModel.Unbaked(Optional.empty(), property, scale, entries, Optional.empty());
	}

	public static net.minecraft.client.renderer.item.ItemModel.Unbaked conditional(
		final ConditionalItemModelProperty property,
		final net.minecraft.client.renderer.item.ItemModel.Unbaked onTrue,
		final net.minecraft.client.renderer.item.ItemModel.Unbaked onFalse
	) {
		return conditional(Optional.empty(), property, onTrue, onFalse);
	}

	public static net.minecraft.client.renderer.item.ItemModel.Unbaked conditional(
		final Transformation transformation,
		final ConditionalItemModelProperty property,
		final net.minecraft.client.renderer.item.ItemModel.Unbaked onTrue,
		final net.minecraft.client.renderer.item.ItemModel.Unbaked onFalse
	) {
		return conditional(Optional.of(transformation), property, onTrue, onFalse);
	}

	public static net.minecraft.client.renderer.item.ItemModel.Unbaked conditional(
		final Optional<Transformation> transformation,
		final ConditionalItemModelProperty property,
		final net.minecraft.client.renderer.item.ItemModel.Unbaked onTrue,
		final net.minecraft.client.renderer.item.ItemModel.Unbaked onFalse
	) {
		return new net.minecraft.client.renderer.item.ConditionalItemModel.Unbaked(transformation, property, onTrue, onFalse);
	}

	public static <T> SwitchCase<T> when(final T value, final net.minecraft.client.renderer.item.ItemModel.Unbaked model) {
		return new SwitchCase<>(List.of(value), model);
	}

	public static <T> SwitchCase<T> when(final List<T> values, final net.minecraft.client.renderer.item.ItemModel.Unbaked model) {
		return new SwitchCase<>(values, model);
	}

	@SafeVarargs
	public static <T> net.minecraft.client.renderer.item.ItemModel.Unbaked select(
		final SelectItemModelProperty<T> property, final net.minecraft.client.renderer.item.ItemModel.Unbaked fallback, final SwitchCase<T>... cases
	) {
		return select(property, fallback, List.of(cases));
	}

	public static <T> net.minecraft.client.renderer.item.ItemModel.Unbaked select(
		final SelectItemModelProperty<T> property, final net.minecraft.client.renderer.item.ItemModel.Unbaked fallback, final List<SwitchCase<T>> cases
	) {
		return new net.minecraft.client.renderer.item.SelectItemModel.Unbaked(Optional.empty(), new UnbakedSwitch<>(property, cases), Optional.of(fallback));
	}

	public static <T> net.minecraft.client.renderer.item.ItemModel.Unbaked select(
		final Transformation transformation,
		final SelectItemModelProperty<T> property,
		final net.minecraft.client.renderer.item.ItemModel.Unbaked fallback,
		final List<SwitchCase<T>> cases
	) {
		return new net.minecraft.client.renderer.item.SelectItemModel.Unbaked(
			Optional.of(transformation), new UnbakedSwitch<>(property, cases), Optional.of(fallback)
		);
	}

	@SafeVarargs
	public static <T> net.minecraft.client.renderer.item.ItemModel.Unbaked select(final SelectItemModelProperty<T> property, final SwitchCase<T>... cases) {
		return select(property, List.of(cases));
	}

	public static <T> net.minecraft.client.renderer.item.ItemModel.Unbaked select(final SelectItemModelProperty<T> property, final List<SwitchCase<T>> cases) {
		return new net.minecraft.client.renderer.item.SelectItemModel.Unbaked(Optional.empty(), new UnbakedSwitch<>(property, cases), Optional.empty());
	}

	public static ConditionalItemModelProperty isUsingItem() {
		return new IsUsingItem();
	}

	public static ConditionalItemModelProperty hasComponent(final DataComponentType<?> component) {
		return new HasComponent(component, false);
	}

	public static net.minecraft.client.renderer.item.ItemModel.Unbaked inOverworld(
		final net.minecraft.client.renderer.item.ItemModel.Unbaked ifTrue, final net.minecraft.client.renderer.item.ItemModel.Unbaked ifFalse
	) {
		return select(new ContextDimension(), ifFalse, when(Level.OVERWORLD, ifTrue));
	}

	private static <T extends Comparable<T>> List<SwitchCase<String>> createBlockPropertySwitchCases(
		final Property<T> property, final Map<T, net.minecraft.client.renderer.item.ItemModel.Unbaked> cases
	) {
		return cases.entrySet().stream().sorted(java.util.Map.Entry.comparingByKey()).map(e -> {
			String valueName = property.getName((Comparable)e.getKey());
			return new SwitchCase(List.of(valueName), (net.minecraft.client.renderer.item.ItemModel.Unbaked)e.getValue());
		}).toList();
	}

	public static <T extends Comparable<T>> net.minecraft.client.renderer.item.ItemModel.Unbaked selectBlockItemProperty(
		final Property<T> property,
		final net.minecraft.client.renderer.item.ItemModel.Unbaked fallback,
		final Map<T, net.minecraft.client.renderer.item.ItemModel.Unbaked> cases
	) {
		return select(new ItemBlockState(property.getName()), fallback, createBlockPropertySwitchCases(property, cases));
	}

	public static <T extends Comparable<T>> net.minecraft.client.renderer.item.ItemModel.Unbaked selectBlockItemProperty(
		final Transformation transformation,
		final Property<T> property,
		final net.minecraft.client.renderer.item.ItemModel.Unbaked fallback,
		final Map<T, net.minecraft.client.renderer.item.ItemModel.Unbaked> cases
	) {
		return select(transformation, new ItemBlockState(property.getName()), fallback, createBlockPropertySwitchCases(property, cases));
	}

	public static net.minecraft.client.renderer.item.ItemModel.Unbaked isXmas(
		final net.minecraft.client.renderer.item.ItemModel.Unbaked onTrue, final net.minecraft.client.renderer.item.ItemModel.Unbaked onFalse
	) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd", Locale.ROOT);
		List<String> days = SpecialDates.CHRISTMAS_RANGE.stream().map(formatter::format).toList();
		return select(LocalTime.create("MM-dd", "", Optional.empty()), onFalse, List.of(when(days, onTrue)));
	}
}
